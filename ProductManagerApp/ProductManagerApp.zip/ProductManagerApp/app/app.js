﻿var productManagerApp = angular.module('productApp', []);
